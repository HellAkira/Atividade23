package Servico;

public abstract class BaseServico {
	
	
	
}
